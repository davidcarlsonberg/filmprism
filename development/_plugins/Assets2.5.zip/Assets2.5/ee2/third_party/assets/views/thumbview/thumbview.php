<div class="assets-thumbview">
	<ul>
		<?php echo $this->load->view('thumbview/files') ?>
	</ul>
	<div style="clear: left;"></div>
</div>
