(function($) {


Matrix.bind('fieldpack_pill', 'display', function(cell){
	new ptPill($('select', this));
});


})(jQuery);
