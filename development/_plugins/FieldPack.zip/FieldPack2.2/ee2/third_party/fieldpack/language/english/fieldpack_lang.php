<?php

$lang = array(


'fieldpack_checkboxes_options'    => 'Checkbox Options',
'fieldpack_dropdown_options'      => 'Dropdown Options',
'fieldpack_multiselect_options'   => 'Multiselect Options',
'fieldpack_radio_buttons_options' => 'Radio&nbsp;Button Options',
'fieldpack_pill_options' => 'Pill Options',
'fieldpack_switch_on_label'  => 'ON Label',
'fieldpack_switch_on_val'    => 'ON Value',
'fieldpack_switch_off_label' => 'OFF Label',
'fieldpack_switch_off_val'   => 'OFF Value',
'fieldpack_switch_default'   => 'Default Position',
'no_options_set' => 'You haven&rsquo;t set any options yet.',

'option_setting_examples' => '<i>ex 1:</i>  <code style="font-size:0.9em">Option Label</code><br/>'
                           . '<i>ex 2:</i>  <code style="font-size:0.9em">option_name : Option Label</code>',


''=>''
);
