<?php

$lang = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

'ajw_datagrab_module_name'		=> 'DataGrab',
'ajw_datagrab_module_description'	=> 'Generic data import module',

//----------------------------------------

// END
''=>''
);

/* End of file lang.ajw_datagrab.php */