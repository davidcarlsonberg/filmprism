<?php

if (! defined('FIELDPACK_VER'))
{
	define('FIELDPACK_VER',  '2.2');
}

$config['name']    = 'P&T Field Pack';
$config['version'] = FIELDPACK_VER;
$config['nsm_addon_updater']['versions_xml'] = 'http://pixelandtonic.com/fieldpack/releasenotes.rss';
