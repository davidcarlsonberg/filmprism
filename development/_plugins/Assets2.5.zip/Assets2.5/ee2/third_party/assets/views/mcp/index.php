<?php
	$vars['lib'] = $lib;
	$vars['mode'] = 'full';
	$this->load->view('filemanager/filemanager', $vars);
?>
