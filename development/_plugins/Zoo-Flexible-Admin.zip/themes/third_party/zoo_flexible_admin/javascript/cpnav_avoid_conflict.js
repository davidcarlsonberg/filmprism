var jQuery13 = jQuery;
jQuery.noConflict(true);